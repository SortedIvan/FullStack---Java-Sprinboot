
import React, { Component, useState, useEffect } from "react";
import { Switch, Route, Link, BrowserRouter } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
//import "./App.css";
import SignIn from "./components/login/Login";
import Header from './components/header/Header';
import Home from "./components/home/Home";
import About from "./components/about/About";
import GamePage from "./components/game/GamePage";
import Register from "./components/register/Register";
import Navbar from "./components/navbar/Navbar";
import NavigationBar from "./components/NavigationBar/NavigationBar";
import UserPage from "./components/users/UserPage";
export default class App extends Component {
  render() {
    return (
      <div className = "App">
        <NavigationBar/>
        {/* <Header/> */}
        <Switch>
        <Route exact path = "/register" component = {Register}/>
        <Route exact path = "/login" component = {SignIn}/>
        <Route path = "/AboutUs" component = {About}/>
        <Route path = "/games" component = {GamePage}/>
        <Route path = "/users" component = {UserPage}/>
        </Switch>


        

      </div>
    )
  }
}
