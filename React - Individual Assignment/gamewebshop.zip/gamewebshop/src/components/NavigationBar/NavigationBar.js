import React from "react";
import styled from "styled-components";
import {
  Navbar,
  Nav,
  Form,
  FormControl,
  Button,
  Container,
} from "react-bootstrap";
import { Fragment } from "react";


var isLoggedIn = false;
var isUser = false;

const user = JSON.parse(localStorage.getItem("user"));
const Logo = styled.a`
padding: 1rem 0;
color: #7b7fda;
text-decoration: none;
font-weight: 700;
font-size: 1.7rem;

span{
    font-weight: 300;
    font-size: 1.3rem;
}


`;

if (user && user.accessToken) {
  console.log(user.roles)
  isLoggedIn = true;
}

if (user && user.roles.includes("[ROLE_USER]")) {
  isUser = true;
}

const NavigationBar = () => {

function LogOut(){
    localStorage.clear();
}

  let menu = "";

  if (isLoggedIn === false) {
    menu = (
      <Fragment>
        <Nav>
          <Button style={{ float: "right" }} href="/login">
            Sign in
          </Button>
          &nbsp;&nbsp;
          <br />
          <Button style={{ float: "right" }} href="/register">
            Register
          </Button>
          &nbsp;&nbsp;
          <br />
        </Nav>
      </Fragment>
    );
  } else if (isLoggedIn === true && isUser === false) {
    //is admin
    menu = (
      <Fragment>
         <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: "200px"}}
              navbarScroll
              
            >
              
              <Nav.Link href="/users">All users</Nav.Link>
         </Nav>
        <Nav>
          <Button href="/profile">Your account</Button>
          &nbsp;&nbsp;
          <br />
          </Nav>
          <Nav>
          <Button href="/sign-out" onClick = {LogOut}>Sign out</Button>
          &nbsp;&nbsp;
          <br />
        </Nav>
      </Fragment>
    );
  } else if (isLoggedIn === true && isUser === true) {
    //is user
    menu = (
      <Fragment>
           <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: "200px"}}
              navbarScroll>
            <Nav.Link href="/complaints">Send a complaint</Nav.Link>
         </Nav>
        <Nav>
          <Button href="/profile">Your account</Button>
          &nbsp;&nbsp;
          <br />
          </Nav>
          <Nav>
          <Button href="/sign-out"  onClick = {LogOut} >Sign out</Button>
          &nbsp;&nbsp;
          <br />
        </Nav>
      </Fragment>
    );
  }

  return (
    <div className="playvera">
      <Navbar bg="light" expand="lg" variant="light">
        <Container fluid>
          <Logo href="/AboutUs">Play<span>vera</span></Logo>
          
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
          <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: "200px"}}
              navbarScroll
              
            >
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <Nav.Link href="/AboutUs">About us</Nav.Link>
              <Nav.Link href="/games">All Games</Nav.Link>
              <Nav.Link href="/creategame">Add your own game</Nav.Link>
           
            </Nav>

            <Nav>{menu}</Nav>

            <Form className="d-flex">
              <FormControl
                type="search"
                placeholder="Search..."
                className="me-2"
                aria-label="Search"
              />
              <Button>Search Games</Button>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};

export default NavigationBar;
