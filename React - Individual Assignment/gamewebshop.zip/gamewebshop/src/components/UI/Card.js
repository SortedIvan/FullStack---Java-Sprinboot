import '/React and Backend GIT/semester3-individual-assignment/React - Individual Assignment/gamewebshop/src/components/UI/Card.module.css';
function Card(props){
    return <div className = "card">{props.children}</div>;
}
export default Card;