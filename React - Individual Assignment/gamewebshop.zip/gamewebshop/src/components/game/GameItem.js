import React from 'react';
// import Card from '../UI/Card';
import { Link } from 'react-router-dom';
import {Card, Button, CardGroup} from 'react-bootstrap';
import { CardDeck } from 'reactstrap';
// import unnamed from '.../public/unnamed.png'

function GameItem(props){
    return (
        // <li key = {props.game.id}>
        //     <Card>
        //         <div>
        //             <h3>{props.game.gameName}</h3>
        //             <h1>{props.game.gamePrice}</h1>
        //             <p>{props.game.gamePlayType}</p>
        //         </div>
        //         <div>
        //             <button onClick = {()=> props.onDelete(props.game.id)}>Delete Game</button>
        //         </div>
        //     </Card>
        // </li>
        <Card style={{display: 'block', justifyContent: 'center', width: '18rem', flex:'1', margin: '3rem'}}>
            <Card.Img variant="top" src={window.location.origin + '/unnamed.png'}/>
                 <Card.Body>
                <Card.Title>{props.game.gameName}</Card.Title>
                <Card.Subtitle>{props.game.gamePlayType}</Card.Subtitle>
                <Card.Text>
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
                </Card.Text>
            <Button variant="primary">View characteristics{props.game.gamePrice}$</Button>
            <Button variant="secondary">Purchase now!{props.game.gamePrice}$</Button>
            </Card.Body>
        </Card>



    )

}
export default GameItem;
