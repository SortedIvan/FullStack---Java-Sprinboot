import { React,useEffect, useState, Fragment, useRef } from "react";
import { Button } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import authService from "../../services/auth.service";
import GameService from "../../services/GameService";

  var isLoggedIn = false;

  if(authService.getCurrentUser() !== null){
      isLoggedIn = true;
  }

  const CreateGame = () => { 

    const [user,setUser] = useState(null);
    useEffect(() => {                                               
      const username = JSON.parse(localStorage.getItem("user"));
      
      if(username && username.user){
      setUser(username.user);
      }
    }, []);

    const gameName = useRef();
    const gameSize = useRef();
    const gamePrice = useRef();
    const gamePlayType = useRef();
    const gamePlayVariant = useRef();
    // const sentDate = useRef();

    const handleSubmit = (e) => {
      e.preventDefault();
    const gameNameRef = gameName.current.value;
    const gameSizeRef = gameSize.current.value;
    const gamePriceRef = gamePrice.current.value;
    const gamePlayTypeRef = gamePlayType.current.value;
    const appUserRef = localStorage.getItem("user");
    
    
    
    const game = 
    {
      gameName : gameNameRef,
      gameSize : gameSizeRef,
      gamePrice : gamePriceRef,
      gamePlayType : gamePlayTypeRef,
      appUser : appUserRef,
    }
    console.log(game);
    GameService.saveGame(game);
    }
  
    let menu = '';

  // if(isLoggedIn === false){
  //     menu = (
  //       <Fragment>
  //       <Form.Group>
  //       <Form.Label>Email </Form.Label>
  //       <Form.Control type="email" placeholder="Write your email..." />
  //       </Form.Group>
  //       </Fragment>
  //     )
  // } 
  if(isLoggedIn === true) {
      menu = (
        <Fragment>
        <Form.Label>Username: </Form.Label> <br/>
          <Form.Label>
            {user}
        </Form.Label>
        </Fragment>
      )
  }
  if(!user){
    return <h1>Error 404, page not found</h1>
  }
  else
  {
  return (
     
    <div>
      <Form onSubmit = {handleSubmit}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          {menu}
        </Form.Group>
        <Form.Group>
        <Form.Label>Game name</Form.Label>
        <Form.Control type="text" ref={gameName} placeholder="Write a game name..."/>
        </Form.Group>
        <br/>
        <Form.Group>
        <Form.Label>Game size</Form.Label>
        <Form.Control type="text" ref={gameSize} placeholder="Game size: "/>
        </Form.Group>
        <br/>
        <Form.Group>
        <Form.Label>Game price</Form.Label>
        <Form.Control type="text" ref={gamePrice} placeholder="Game price: "/>
        </Form.Group>
        <br/>
        <Form.Group>
        <Form.Label>Game play type: </Form.Label>
        <Form.Control type="text" ref={gamePlayType} placeholder="Game play type: "/>
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>
    </div>
  );
};
  }

export default CreateGame;