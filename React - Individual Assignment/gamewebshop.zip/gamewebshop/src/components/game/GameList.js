import React from "react";
import GameItem from "./GameItem";
function GameList(props){
    const handleDelete = (id) =>{
        props.onDelete(id);
    };


return(
    <ul>
        {props.games.map((game)=>(
            <GameItem key = {game.id} game = {game} onDelete = {handleDelete}></GameItem>
        ))}
    </ul>
    )

}

export default GameList;