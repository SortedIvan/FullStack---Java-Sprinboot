export default function authHeader() {
    const accessToken = JSON.parse(localStorage.getItem('accessTokens'));
    console.log("Header: "+ accessToken.access_token);
    if (accessToken && accessToken.access_token) {
      return  accessToken.access_token;
      
    } else {
      return {};
    }
  }