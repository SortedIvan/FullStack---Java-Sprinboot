import axios from "axios";

const API_URL = "http://localhost:8080/api/";

const register = (username, email, password) => {
  return axios.post("http://localhost:8080/api/user/save", {
    username,
    email,
    password,
  });
};

const login = (username, password) =>{
    console.log(username);
    console.log(password);
var axios = require('axios');
var qs = require('qs');
var data = qs.stringify({
    'username' : username,
    'password': password
});
var config = {
    method: 'post',
    url: "http://localhost:8080/api/login",
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'

    },
    data : data
    
};
return axios(config)
.then(function(response){
        localStorage.setItem("accessTokens", JSON.stringify(response.data));
        //localStorage.setItem("username", username);
        console.log("accessToken "+JSON.stringify(response.data));
        return response.data;
})
.catch(function(error){
    console.log(error);
});
};


const logout = () => {
  localStorage.removeItem("username");
  localStorage.removeItem("accessTokens");
  localStorage.removeItem("user");
};

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("user"));
};

export default {
  register,
  login,
  logout,
  getCurrentUser,
};
